/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author pcopp8995
 */
public class three extends BasicGameState{
    Image bg,square,blaq;
    Image xd [][] =new Image[3][3];
    Integer random [][] =new Integer[3][3];
    Integer swaps [][] =new Integer[3][3];
    Random r= new Random();
    String mouse="";
    
    String click="";
    int clicks=0;
   private static StateBasedGame game;
   String[] juan;
   boolean yolo=false;
   int hold=0;
   boolean ok=true;
    boolean win=true;
    
    three(int i) throws SlickException {
        
              
              bg = new Image("Images\\play.jpg");
              square= new Image("Images\\square.jpg");
             blaq= new Image("Images\\black3.png");
       
          //getsubimage    
              
    }

    @Override
    public int getID() {
       return 7; 
    }

    @Override
 
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        game=sbg;
        
        xd[0][0]=square.getSubImage(0, 0, 160, 160);
        xd[0][1]=square.getSubImage(160, 0, 160, 160);
        xd[0][2]=square.getSubImage(320, 0, 160, 160);
        xd[1][0]=square.getSubImage(0, 160, 160, 160);
        xd[1][1]=square.getSubImage(160, 160, 160, 160);
        xd[1][2]=square.getSubImage(320, 160, 160, 160);
        xd[2][0]=square.getSubImage(0, 320, 160, 160);
        xd[2][1]=square.getSubImage(160, 320, 160, 160);
        xd[2][2]=blaq;
        
        random[0][0]=0;
        random[0][1]=1;
        random[0][2]=2;
        random[1][0]=3;
        random[1][1]=4;
        random[1][2]=5;
        random[2][0]=6;
        random[2][1]=7;
        random[2][2]=8;
        
        
        
        
        Random rn = new Random();
        
        //1 is x, 2 is y
        //1 is pos 2 is neg
        
        for(int c2=0;c2<10000;c2++){
        for(int c=0;c<3;c++){
            for(int c1=0;c1<3;c1++){
                if(random[c][c1]==8){
                   int xory = rn.nextInt(2) + 1;
                   int plusminus = rn.nextInt(2) + 1;
                   
                   
                      if(xory==1){
                         if((plusminus==1 && c!=2)  || (c==0)){
                             hold=random[c+1][c1];
                             random[c+1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c-1][c1];
                             random[c-1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         
                      }
                      
                      
                      else{
                         if((plusminus==1 && c1!=2) || (c1==0)){
                             hold=random[c][c1+1];
                             random[c][c1+1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c][c1-1];
                             random[c][c1-1]=random[c][c1];
                             random[c][c1]=hold;
                         } 
                           
                      
                       
                   }
                    
                }
                
            }
            
      }
    }
        
    
      
        
         
  }
        
        
    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {
        bg.draw(0,0);
        
        
        for(int c1=0;c1<3;c1++){
            
            for(int c=0;c<3;c++){
            if(random[c1][c]==0){
                xd[0][0].draw(38+c*160,60+c1*160);
               
            }
            if(random[c1][c]==1){
                xd[0][1].draw(38+c*160,60+c1*160);
            }
            if(random[c1][c]==2){
                xd[0][2].draw(38+c*160,60+c1*160);
            }
            if(random[c1][c]==3){
                xd[1][0].draw(38+c*160,60+c1*160);
            }
            if(random[c1][c]==4){
                xd[1][1].draw(38+c*160,60+c1*160);
            }
            if(random[c1][c]==5){
                xd[1][2].draw(38+c*160,60+c1*160);
            }
            if(random[c1][c]==6){
                xd[2][0].draw(38+c*160,60+c1*160);
            }
            if(random[c1][c]==7){
                xd[2][1].draw(38+c*160,60+c1*160);
            }
            if(random[c1][c]==8){
                xd[2][2].draw(38+c*160,60+c1*160);
            }
            
            
            
            }
              
        }
        
       
        grphcs.setColor(Color.white);
        click=String.valueOf(Globals.clicks);
        grphcs.drawString(click, 130, 25);
        
        grphcs.drawString(mouse, 10, 20);
        
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
        
        Input input=gc.getInput();
       int mousex=input.getMouseX();
       int mousey=input.getMouseY();
       mouse=" X: "+mousex+"    Y: "+mousey;
       
       if(input.isMouseButtonDown(0)&& mousex<530 && mousex>50 && mousey>60 && mousey<540){
           yolo=true;
       }
       
       
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<198 && mousex>38 && mousey>60 && mousey<220&& yolo){
           
           if(random[0][1]==8 || random[1][0]==8){
           hold=random[0][0];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[0][0]=8;
           }
           yolo=false;
           
       }
       
        if(!input.isMouseButtonDown(0) && mousex<358 && mousex>198 && mousey>60 && mousey<220&& yolo){
            if(random[0][0]==8 || random[0][2]==8 || random[1][1]==8){
           hold=random[0][1];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[0][1]=8;
            }
           yolo=false;
           
       }
       
       
       if(!input.isMouseButtonDown(0) && mousex<518 && mousex>358 && mousey>60 && mousey<220&& yolo){
           if(random[0][1]==8 || random[1][2]==8){
           hold=random[0][2];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[0][2]=8;
           }
           yolo=false;
           
       }
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<198 && mousex>38 && mousey>220 && mousey<380&& yolo){
           if(random[0][0]==8 || random[1][1]==8 || random[2][0]==8){
           hold=random[1][0];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[1][0]=8;
           }
           yolo=false;
           
       }
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<358 && mousex>198 && mousey>220 && mousey<380&& yolo){
           if(random[0][1]==8 || random[1][0]==8 || random[1][2]==8 || random[2][1]==8){
           hold=random[1][1];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[1][1]=8;
           }
           yolo=false;
           
       }
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<518 && mousex>358 && mousey>220 && mousey<380&& yolo){
           if(random[0][2]==8 || random[1][1]==8 || random[2][2]==8){
           hold=random[1][2];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[1][2]=8;
           }
           yolo=false;
           
       }
       
       
       
        if(!input.isMouseButtonDown(0) && mousex<198 && mousex>38 && mousey>380 && mousey<540 && yolo){
            if(random[1][0]==8 || random[2][1]==8){
           hold=random[2][0];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][0]=8;
            }
           yolo=false;
           
       }
       
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<358 && mousex>198 && mousey>380 && mousey<540 && yolo){
           if(random[2][0]==8 || random[1][1]==8 || random [2][2]==8){
           hold=random[2][1];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][1]=8;
           }
           yolo=false;
           
       }
       
       
       if(!input.isMouseButtonDown(0) && mousex<518 && mousex>358 && mousey>380 && mousey<540 && yolo){
           if(random[1][2]==8 || random[2][1]==8){
           hold=random[2][2];
           Globals.clicks++;
           for(int c1=0;c1<3;c1++){
            for(int c=0;c<3;c++){
                if(random[c1][c]==8){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][2]=8;
           }
           yolo=false;
           
       }
       
       
       win=wincheck(random);
       
       
       if(win){
           
           Random rn = new Random();
           
           if(Globals.clicks<Globals.score[3]){
          sbg.enterState(4, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150)); 
          
           }
           else{
               sbg.enterState(2, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150)); 
               
           }
           
           
           
           
           
          
      for(int c2=0;c2<10000;c2++){
        for(int c=0;c<3;c++){
            for(int c1=0;c1<3;c1++){
                if(random[c][c1]==8){
                   int xory = rn.nextInt(2) + 1;
                   int plusminus = rn.nextInt(2) + 1;
                   
                   
                      if(xory==1){
                         if((plusminus==1 && c!=2)  || (c==0)){
                             hold=random[c+1][c1];
                             random[c+1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c-1][c1];
                             random[c-1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         
                      }
                      
                      
                      else{
                         if((plusminus==1 && c1!=2) || (c1==0)){
                             hold=random[c][c1+1];
                             random[c][c1+1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c][c1-1];
                             random[c][c1-1]=random[c][c1];
                             random[c][c1]=hold;
                         } 
                           
                      
                       
                   }
                    
                }
                
            }
            
      }
    }
   }
       
       
       
       
       if(input.isMouseButtonDown(0) && mousex<535 && mousex>405 && mousey>23 && mousey<50){
           yolo=false;
           sbg.enterState(1, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       
       
       
       
       
      
        
    }
    
    
    public boolean wincheck(Integer[][]random){
        boolean dank=false;
        
        if(random[0][0]==0 && random[0][1]==1 && random[0][2]==2 && random[1][0]==3 && random[1][1]==4 && random[1][2]==5 && random[2][0]==6 && random[2][1]==7 && random[2][2]==8){
            dank=true;
            
             
        }
        
        return dank;
    }
    
    
    
    
    
    
    
    
    
}