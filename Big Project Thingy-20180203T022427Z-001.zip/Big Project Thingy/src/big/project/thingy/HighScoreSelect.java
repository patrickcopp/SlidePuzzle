/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author pcopp8995
 */
public class HighScoreSelect extends BasicGameState{
    Image bg,circle;
    Random r= new Random();
    String mouse="";
    String name="";
    boolean back=false;
   private static StateBasedGame game;
   int hold=100;
   // boolean[] dotVis ;
    
    HighScoreSelect(int i) throws SlickException {
        
              
              bg = new Image("Images\\namescreen.jpg");
            
             
       
              
              
    }

    @Override
    public int getID() {
       return 4; 
    }
    
  
    
    @Override
 
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        
        game=sbg;
        
        
    }

    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {
        bg.draw(0,0);
        grphcs.drawString(mouse, 10, 20);
        grphcs.drawString(name, 347, 293);
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
        
        Input input=gc.getInput();
       int mousex=input.getMouseX();
       int mousey=input.getMouseY();
       mouse=" X: "+mousex+"    Y: "+mousey;
       
       
       
       
        if (input.isKeyPressed(Input.KEY_A) && name.length()<3) {
            name+="A";
        }
       if (input.isKeyPressed(Input.KEY_B)&& name.length()<3) {
            name+="B";
        }
       if (input.isKeyPressed(Input.KEY_C)&& name.length()<3) {
            name+="C";
        }
       if (input.isKeyPressed(Input.KEY_D)&& name.length()<3) {
            name+="D";
        }
       if (input.isKeyPressed(Input.KEY_E)&& name.length()<3) {
            name+="E";
        }
       if (input.isKeyPressed(Input.KEY_F)&& name.length()<3) {
            name+="F";
        }
       if (input.isKeyPressed(Input.KEY_G)&& name.length()<3) {
            name+="G";
        }
       if (input.isKeyPressed(Input.KEY_H)&& name.length()<3) {
            name+="H";
        }
       if (input.isKeyPressed(Input.KEY_I)&& name.length()<3) {
            name+="I";
        }
       if (input.isKeyPressed(Input.KEY_J)&& name.length()<3) {
            name+="J";
        }
       if (input.isKeyPressed(Input.KEY_K)&& name.length()<3) {
            name+="K";
        }
       
               if (input.isKeyPressed(Input.KEY_L)&& name.length()<3) {
            name+="L";
        }
               if (input.isKeyPressed(Input.KEY_M)&& name.length()<3) {
            name+="M";
        }
               if (input.isKeyPressed(Input.KEY_N)&& name.length()<3) {
            name+="N";
        }
               if (input.isKeyPressed(Input.KEY_O)&& name.length()<3) {
            name+="O";
        }
               if (input.isKeyPressed(Input.KEY_P)&& name.length()<3) {
            name+="P";
        }
               if (input.isKeyPressed(Input.KEY_Q)&& name.length()<3) {
            name+="Q";
        }
               if (input.isKeyPressed(Input.KEY_R)&& name.length()<3) {
            name+="R";
        }
               if (input.isKeyPressed(Input.KEY_S)&& name.length()<3) {
            name+="S";
        }
               if (input.isKeyPressed(Input.KEY_T)&& name.length()<3) {
            name+="T";
        }
               if (input.isKeyPressed(Input.KEY_U)&& name.length()<3) {
            name+="U";
        }
               if (input.isKeyPressed(Input.KEY_V)&& name.length()<3) {
            name+="V";
        }
               if (input.isKeyPressed(Input.KEY_W)&& name.length()<3) {
            name+="W";
        }
               if (input.isKeyPressed(Input.KEY_X)&& name.length()<3) {
            name+="X";
        }
               
           if (input.isKeyPressed(Input.KEY_Y)&& name.length()<3) {
            name+="Y";
        }
           if (input.isKeyPressed(Input.KEY_Z)&& name.length()<3) {
            name+="Z";
        }
           
             if (input.isKeyPressed(Input.KEY_BACK)&& name.length()>0) {
            name=name.substring(0,name.length()-1);
        }      
       
           if (input.isKeyPressed(Input.KEY_ENTER)&& name.length()==3) {
            if(Globals.clicks<Globals.score[0]){
            
            Globals.juan[3]=Globals.juan[2];
            Globals.juan[2]=Globals.juan[1];
            Globals.juan[1]=Globals.juan[0];
            Globals.juan[0]=name+String.valueOf(Globals.clicks);
            Globals.score[3]=Globals.score[2];
            Globals.score[2]=Globals.score[1];
            Globals.score[1]=Globals.score[0];
            Globals.score[0]=Globals.clicks;
        }
        else if(Globals.clicks<Globals.score[1]){
            Globals.juan[3]=Globals.juan[2];
            Globals.juan[2]=Globals.juan[1];
            Globals.juan[1]=name+String.valueOf(Globals.clicks);
            Globals.score[3]=Globals.score[2];
            Globals.score[2]=Globals.score[1];
            Globals.score[1]=Globals.clicks;
        }
        else if(Globals.clicks<Globals.score[2]){
            Globals.juan[3]=Globals.juan[2];
            Globals.juan[2]=name+String.valueOf(Globals.clicks);
            Globals.score[3]=Globals.score[2];
            Globals.score[2]=Globals.clicks;
        }
        else if(Globals.clicks<Globals.score[3]){
            Globals.juan[3]=name+String.valueOf(Globals.clicks);
            Globals.score[3]=Globals.clicks;
        }
            Globals.clicks=0;
            name="";
            
            BufferedWriter WriteFile;
            try {
                WriteFile = new BufferedWriter(new FileWriter("scores.txt"));
                 WriteFile.write(Globals.juan[0]+" "+Globals.juan[1]+" "+Globals.juan[2]+" "+Globals.juan[3]);
                WriteFile.close();
                
                
            } catch (IOException ex) {
                Logger.getLogger(High.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            
            
           sbg.enterState(2, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));  
        }
           
          if(input.isMouseButtonDown(0) && mousex<555 && mousex>477 && mousey>520 && mousey<555){
           sbg.enterState(2, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
           
       } 
           
       
       
       
    }
}