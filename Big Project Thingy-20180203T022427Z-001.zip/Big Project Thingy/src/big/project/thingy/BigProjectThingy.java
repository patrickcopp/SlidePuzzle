/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

/**
 *
 * @author ereinke7771
 */
public class BigProjectThingy extends StateBasedGame{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SlickException {
       
         AppGameContainer app = new AppGameContainer(new BigProjectThingy("Culminating"));
      app.setShowFPS(true);
      app.setDisplayMode(555, 555, false);
      app.setVSync(false);
      app.start();
    }

    public BigProjectThingy(String name) {
        super(name);
    }

    @Override
    public void initStatesList(GameContainer gc) throws SlickException {
        
        addState(new Menu(0));
        addState (new Settings(1));
        addState (new High(2));
        addState (new four(3));
        addState (new HighScoreSelect(4));
        addState (new high4(5));
        addState (new sizeselect(6));
        addState (new three(7));
        addState (new highselect(8));
    }
    
}
