/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import java.awt.Font;
import java.util.Random;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.Music;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author pcopp8995
 */
public class Menu extends BasicGameState{
    Image square;
    Random r= new Random();
    String mouse="";
    TrueTypeFont font;
    
    
   private static StateBasedGame game;
   
   // boolean[] dotVis ;
    
    Menu(int i) throws SlickException {
        
              
              square = new Image("Images\\mainmenu.png");
                Music mainMusic;
             
        
    }

    @Override
    public int getID() {
       return 0; //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       
    }

    @Override
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
       game=sbg;
    }

    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {
       square.draw(0,0);
       grphcs.setColor(Color.white);
       grphcs.drawString(mouse, 10, 20);
        
      
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
       Input input=gc.getInput();
       int mousex=input.getMouseX();
       int mousey=input.getMouseY();
       mouse=" X: "+mousex+"    Y: "+mousey;
        
       if(input.isMouseButtonDown(0) && mousex<390 && mousex>160 && mousey>337 && mousey<385){
           sbg.enterState(1,  new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       if(input.isMouseButtonDown(0) && mousex<435 && mousex>130 && mousey>221 && mousey<270){
           sbg.enterState(8,  new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       if(input.isMouseButtonDown(0) && mousex<345 && mousex>210 && mousey>113 && mousey<160){
           sbg.enterState(6,  new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       
       
       
       
       
       if(input.isMouseButtonDown(0) && mousex<334 && mousex>208 && mousey>457 && mousey<505){
           
           gc.exit();
       }
       
      
       
       
       
       
       
       
    }
}
