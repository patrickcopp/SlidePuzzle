/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author pcopp8995
 */
public class four extends BasicGameState{
    Image bg,square,blaq;
    Image xd [][] =new Image[4][4];
    Integer random [][] =new Integer[4][4];
    
    Random r= new Random();
    String mouse="";
    
    String click="";
    int clicks=0;
   private static StateBasedGame game;
   String[] juan;
   boolean yolo=false;
   int hold=0;
   boolean ok=true;
    boolean win=true;
    
    four(int i) throws SlickException {
        
              
              bg = new Image("Images\\play.jpg");
              square= new Image("Images\\square2.png");
             blaq= new Image("Images\\black3.png");
       
          //getsubimage    
              
    }

    @Override
    public int getID() {
       return 3; 
    }

    @Override
 
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        game=sbg;
        
        xd[0][0]=square.getSubImage(  0,   0, 120, 120);
        xd[0][1]=square.getSubImage(120,   0, 120, 120);
        xd[0][2]=square.getSubImage(240,   0, 120, 120);
        xd[0][3]=square.getSubImage(360,   0, 120, 120);
        xd[1][0]=square.getSubImage(  0, 120, 120, 120);
        xd[1][1]=square.getSubImage(120, 120, 120, 120);
        xd[1][2]=square.getSubImage(240, 120, 120, 120);
        xd[1][3]=square.getSubImage(360, 120, 120, 120);
        xd[2][0]=square.getSubImage(  0, 240, 120, 120);
        xd[2][1]=square.getSubImage(120, 240, 120, 120);
        xd[2][2]=square.getSubImage(240, 240, 120, 120);
        xd[2][3]=square.getSubImage(360, 240, 120, 120);
        xd[3][0]=square.getSubImage(  0, 360, 120, 120);
        xd[3][1]=square.getSubImage(120, 360, 120, 120);
        xd[3][2]=square.getSubImage(240, 360, 120, 120);
        xd[3][3]=blaq.getSubImage(0, 0, 120, 120);
        
        random[0][0]=0;
        random[0][1]=1;
        random[0][2]=2;
        random[0][3]=3;
        random[1][0]=4;
        random[1][1]=5;
        random[1][2]=6;
        random[1][3]=7;
        random[2][0]=8;
        random[2][1]=9;
        random[2][2]=10;
        random[2][3]=11;
        random[3][0]=12;
        random[3][1]=13;
        random[3][2]=14;
        random[3][3]=15;
        
        
        Random rn = new Random();
        
        //1 is x, 2 is y
        //1 is positive 2 is neg
        
        for(int c2=0;c2<10000;c2++){
        for(int c=0;c<4;c++){
            for(int c1=0;c1<4;c1++){
                if(random[c][c1]==15){
                   int xory = rn.nextInt(2) + 1;
                   int plusminus = rn.nextInt(2) + 1;
                   
                   
                      if(xory==1){
                         if((plusminus==1 && c!=3)  || (c==0)){
                             hold=random[c+1][c1];
                             random[c+1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c-1][c1];
                             random[c-1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         
                      }
                      
                      
                      else{
                         if((plusminus==1 && c1!=3) || (c1==0)){
                             hold=random[c][c1+1];
                             random[c][c1+1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c][c1-1];
                             random[c][c1-1]=random[c][c1];
                             random[c][c1]=hold;
                         } 
                           
                      
                       
                   }
                    
                }
                
            }
            
      }
    }
        
    
      
        
         
  }
        
        
    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {
        bg.draw(0,0);
        
        
        for(int c1=0;c1<4;c1++){
            
            for(int c=0;c<4;c++){
            if(random[c1][c]==0){
                xd[0][0].draw(38+c*120,60+c1*120);
               
            }
            if(random[c1][c]==1){
                xd[0][1].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==2){
                xd[0][2].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==3){
                xd[0][3].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==4){
                xd[1][0].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==5){
                xd[1][1].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==6){
                xd[1][2].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==7){
                xd[1][3].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==8){
                xd[2][0].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==9){
                xd[2][1].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==10){
                xd[2][2].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==11){
                xd[2][3].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==12){
                xd[3][0].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==13){
                xd[3][1].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==14){
                xd[3][2].draw(38+c*120,60+c1*120);
            }
            if(random[c1][c]==15){
                xd[3][3].draw(38+c*120,60+c1*120);
            }
            
            }
              
        }
        
       
        grphcs.setColor(Color.white);
        click=String.valueOf(Globals.clicks4);
        grphcs.drawString(click, 130, 25);
        
        grphcs.drawString(mouse, 10, 20);
        
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
        
        Input input=gc.getInput();
       int mousex=input.getMouseX();
       int mousey=input.getMouseY();
       mouse=" X: "+mousex+"    Y: "+mousey;
       
       if(input.isMouseButtonDown(0)&& mousex<530 && mousex>50 && mousey>60 && mousey<540){
           yolo=true;
       }
       
       
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<158 && mousex>38 && mousey>60 && mousey<180&& yolo){
           
           if(random[0][1]==15 || random[1][0]==15){
           hold=random[0][0];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[0][0]=15;
           }
           yolo=false;
           
       }
       
       if(!input.isMouseButtonDown(0) && mousex<278 && mousex>158 && mousey>60 && mousey<180&& yolo){
           
           if(random[0][0]==15 || random[0][2]==15|| random[1][1]==15){
           hold=random[0][1];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[0][1]=15;
           }
           yolo=false;
           
       } 
       
       
    if(!input.isMouseButtonDown(0) && mousex<398 && mousex>278 && mousey>60 && mousey<180&& yolo){
           
           if(random[0][1]==15 || random[0][3]==15|| random[1][2]==15){
           hold=random[0][2];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[0][2]=15;
           }
           yolo=false;
           
       }
        
        if(!input.isMouseButtonDown(0) && mousex<518 && mousex>398 && mousey>60 && mousey<180&& yolo){
           
           if(random[0][2]==15 ||  random[1][3]==15){
           hold=random[0][3];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[0][3]=15;
           }
           yolo=false;
           
       }
        
        
        
        //2nd ROW
        
        
               
       if(!input.isMouseButtonDown(0) && mousex<158 && mousex>38 && mousey>180 && mousey<300&& yolo){
           
           if(random[0][0]==15 || random[2][0]==15|| random[1][1]==15){
           hold=random[1][0];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[1][0]=15;
           }
           yolo=false;
           
       }
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<278 && mousex>158 && mousey>180 && mousey<300&& yolo){
           
           if(random[1][0]==15 || random[1][2]==15|| random[2][1]==15|| random[0][1]==15){
           hold=random[1][1];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[1][1]=15;
           }
           yolo=false;
           
       } 
       
       
    if(!input.isMouseButtonDown(0) && mousex<398 && mousex>278 && mousey>180 && mousey<300&& yolo){
           
           if(random[1][1]==15 || random[1][3]==15|| random[2][2]==15|| random[0][2]==15){
           hold=random[1][2];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[1][2]=15;
           }
           yolo=false;
           
       }
        
        if(!input.isMouseButtonDown(0) && mousex<518 && mousex>398 && mousey>180 && mousey<300&& yolo){
           
           if(random[1][2]==15 ||  random[0][3]==15||  random[2][3]==15){
           hold=random[1][3];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[1][3]=15;
           }
           yolo=false;
           
       }
        
        
        
        //3RD ROW
        
        if(!input.isMouseButtonDown(0) && mousex<158 && mousex>38 && mousey>300 && mousey<420&& yolo){
           
           if(random[1][0]==15 || random[3][0]==15|| random[2][1]==15){
           hold=random[2][0];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][0]=15;
           }
           yolo=false;
           
       }
       
       
       
       if(!input.isMouseButtonDown(0) && mousex<278 && mousex>158 && mousey>300 && mousey<420&& yolo){
           
           if(random[2][0]==15 || random[2][2]==15|| random[3][1]==15|| random[1][1]==15){
           hold=random[2][1];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][1]=15;
           }
           yolo=false;
           
       } 
       
       
    if(!input.isMouseButtonDown(0) && mousex<398 && mousex>278 && mousey>300 && mousey<420&& yolo){
           
           if(random[2][1]==15 || random[2][3]==15|| random[3][2]==15|| random[1][2]==15){
           hold=random[2][2];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][2]=15;
           }
           yolo=false;
           
       }
        
        if(!input.isMouseButtonDown(0) && mousex<518 && mousex>398 && mousey>300 && mousey<420&& yolo){
           
           if(random[2][2]==15 ||  random[1][3]==15||  random[3][3]==15){
           hold=random[2][3];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][3]=15;
           }
           yolo=false;
           
       }
        
        
        
        
        
         if(!input.isMouseButtonDown(0) && mousex<518 && mousex>398 && mousey>300 && mousey<420&& yolo){
           
           if(random[2][2]==15 ||  random[1][3]==15||  random[3][3]==15){
           hold=random[2][3];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[2][3]=15;
           }
           yolo=false;
           
       }
         
         
         //4th row
        
        if(!input.isMouseButtonDown(0) && mousex<158 && mousex>38 && mousey>420 && mousey<540&& yolo){
           
           if(random[3][1]==15 || random[2][0]==15){
           hold=random[3][0];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[3][0]=15;
           }
           yolo=false;
           
       }
       
       if(!input.isMouseButtonDown(0) && mousex<278 && mousex>158 && mousey>420 && mousey<540&& yolo){
           
           if(random[3][0]==15 || random[3][2]==15|| random[2][1]==15){
           hold=random[3][1];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[3][1]=15;
           }
           yolo=false;
           
       } 
       
       
    if(!input.isMouseButtonDown(0) && mousex<398 && mousex>278 && mousey>420 && mousey<540&& yolo){
           
           if(random[3][1]==15 || random[3][3]==15|| random[2][2]==15){
           hold=random[3][2];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[3][2]=15;
           }
           yolo=false;
           
       }
        
    if(!input.isMouseButtonDown(0) && mousex<518 && mousex>398 && mousey>420 && mousey<540&& yolo){
           
           if(random[3][2]==15 ||  random[2][3]==15){
           hold=random[3][3];
           Globals.clicks4++;
           for(int c1=0;c1<4;c1++){
            for(int c=0;c<4;c++){
                if(random[c1][c]==15){
                    random[c1][c]=hold;
                }
                
            }
          }
           random[3][3]=15;
           }
           yolo=false;
           
       }
        
       win=wincheck(random);
       
       
       if(win){
           
           Random rn = new Random();
           
           if(Globals.clicks4<Globals.score[3]){
          sbg.enterState(5, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150)); 
          
           }
           else{
               sbg.enterState(2, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150)); 
               
           }
           
          
      for(int c2=0;c2<10000;c2++){
        for(int c=0;c<4;c++){
            for(int c1=0;c1<4;c1++){
                if(random[c][c1]==15){
                   int xory = rn.nextInt(2) + 1;
                   int plusminus = rn.nextInt(2) + 1;
                   
                   
                      if(xory==1){
                         if((plusminus==1 && c!=3)  || (c==0)){
                             hold=random[c+1][c1];
                             random[c+1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c-1][c1];
                             random[c-1][c1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         
                      }
                      
                      
                      else{
                         if((plusminus==1 && c1!=3) || (c1==0)){
                             hold=random[c][c1+1];
                             random[c][c1+1]=random[c][c1];
                             random[c][c1]=hold;
                         }
                         else{
                             hold=random[c][c1-1];
                             random[c][c1-1]=random[c][c1];
                             random[c][c1]=hold;
                         } 
                           
                      
                       
                   }
                    
                }
                
            }
            
      }
    }
           
           
           
           
   }
       
       
       
       
       if(input.isMouseButtonDown(0) && mousex<535 && mousex>405 && mousey>23 && mousey<50){
           yolo=false;
           sbg.enterState(1, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       
       
       
       
       
         
        
    }
    
    
    public boolean wincheck(Integer[][]random){
        boolean dank=false;
        
        if(random[0][0]==0 && random[0][1]==1 && random[0][2]==2 && random[0][3]==3 &&random[1][0]==4 &&random[1][1]==5 &&random[1][2]==6 &&random[1][3]==7 &&random[2][0]==8 &&random[2][1]==9 &&random[2][2]==10 &&random[2][3]==11 &&random[3][0]==12 &&random[3][1]==13 &&random[3][2]==14 &&random[3][3]==15){
            dank=true;
            
             
        }
        
        return dank;
    }
    
    
}
    
    
    
    
    
    
