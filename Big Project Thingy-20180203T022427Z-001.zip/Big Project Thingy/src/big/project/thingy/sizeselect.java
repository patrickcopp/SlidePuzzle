/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import java.awt.Font;
import java.util.Random;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.Music;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author pcopp8995
 */
public class sizeselect extends BasicGameState{
    Image square;
    Random r= new Random();
    String mouse="";
    TrueTypeFont font;
    
    
   private static StateBasedGame game;
   
   // boolean[] dotVis ;
    
    sizeselect(int i) throws SlickException {
        
              
              square = new Image("Images\\boardselection.jpg");
                Music mainMusic;
             
        
    }

    @Override
    public int getID() {
       return 6; //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       
    }

    @Override
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
       game=sbg;
    }

    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {
       square.draw(0,0);
       grphcs.setColor(Color.white);
       grphcs.drawString(mouse, 10, 20);
        
      
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
       Input input=gc.getInput();
       int mousex=input.getMouseX();
       int mousey=input.getMouseY();
       mouse=" X: "+mousex+"    Y: "+mousey;
        
       if(input.isMouseButtonDown(0) && mousex<400 && mousex>142 && mousey>175 && mousey<200){
           sbg.enterState(7,  new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       if(input.isMouseButtonDown(0) && mousex<293 && mousex>142 && mousey>245 && mousey<268){
           sbg.enterState(3,  new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       
       
       
       
       
       
       
      
       
       
       
       
       
       
    }
}
