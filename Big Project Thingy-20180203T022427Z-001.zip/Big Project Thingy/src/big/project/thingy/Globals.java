/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

/**
 *
 * @author pcopp8995
 */
public class Globals {
    
    public static int clicks=0;
    public static Integer[] score= new Integer[4];
    public static String[] juan= new String[4];
    
     public static String[] juan4= new String[4];
    public static int clicks4=0;
    public static Integer[] score4= new Integer[4];
}
