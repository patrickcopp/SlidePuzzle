/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author pcopp8995
 */
public class High extends BasicGameState{
    Image bg,circle;
    Random r= new Random();
    String mouse="";
    int circlex=247,circley=190,circlesize1=56,circlesize2=33;
    int ccirclex=216,ccircley=303,ccirclesize1=122,ccirclesize2=36;
   private static StateBasedGame game;
   
   String [] scores = null;
   // boolean[] dotVis ;
    
    High(int i) throws SlickException {
        
              
              bg = new Image("Images\\highscore.jpg");
            
             
       
              
              
    }

    @Override
    public int getID() {
       return 2; 
    }

    
    @Override
 
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        
        game=sbg;
        
        try {
            BufferedReader ok = new BufferedReader(new FileReader("scores.txt"));
            
            String file1=ok.readLine();
             scores=file1.split(" ");
             
            
            
        } 
        
        catch (FileNotFoundException ex) {
            Logger.getLogger(High.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(High.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        for(int c=0;c<4;c++){
            if(c<scores.length){
                Globals.score[c]=Integer.parseInt(scores[c].substring(3,scores[c].length()));
                Globals.juan[c]=scores[c];
            }
            else{
                Globals.score[c]=100000000;
                Globals.juan[c]="                                    ";
            }
            
        }
       
                
        
        
        
        
        
        
    }

    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {
        bg.draw(0,0);
        grphcs.drawString(mouse, 10, 20);
        
        for(int c=0;c<Globals.juan.length*100;c+=100){
            grphcs.drawString(c/100+1+". "+Globals.juan[c/100].substring(0,3)+"                       "+Globals.juan[c/100].substring(3,Globals.juan[c/100].length()), 130, 140+c);
            
        }
        
        
        
        
        
     
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
        
        Input input=gc.getInput();
       int mousex=input.getMouseX();
       int mousey=input.getMouseY();
       mouse=" X: "+mousex+"    Y: "+mousey;
       
       if(input.isMouseButtonDown(0) && mousex<550 && mousex>452 && mousey>502 && mousey<537){
           sbg.enterState(0, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
       }
       
       if(input.isMouseButtonDown(0) && mousex<204 && mousex>3 && mousey>502 && mousey<539){
           BufferedWriter WriteFile;
            try {
                WriteFile = new BufferedWriter(new FileWriter("scores.txt"));
                 WriteFile.write(" ");
                WriteFile.close();
                for(int c=0;c<Globals.juan.length;c++){
                Globals.juan[c]="      ";
                Globals.score[c]=10000000;
                }
                
            } catch (IOException ex) {
                Logger.getLogger(High.class.getName()).log(Level.SEVERE, null, ex);
            }
           
           
          
       }
       
       
       
       
       
       
       
       
        
    }
}