/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package big.project.thingy;

import java.util.Random;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 *
 * @author pcopp8995
 */
public class Settings extends BasicGameState{
    Image bg,circle;
    Random r= new Random();
    String mouse="";
    int circlex=247,circley=190,circlesize1=56,circlesize2=33;
    int ccirclex=216,ccircley=303,ccirclesize1=122,ccirclesize2=36;
   private static StateBasedGame game;
   boolean yolo=false;
   
   // boolean[] dotVis ;
    
    Settings(int i) throws SlickException {
        
              
              bg = new Image("Images\\settingsingame.jpg");
            circle = new Image("Images\\box.png");
             
       
              
              
    }
    
    @Override
    public int getID() {
       return 1; 
    }

    @Override
    public void init(GameContainer gc, StateBasedGame sbg) throws SlickException {
        game=sbg;
    }

    @Override
    public void render(GameContainer gc, StateBasedGame sbg, Graphics grphcs) throws SlickException {
        bg.draw(0,0);
       grphcs.setColor(Color.white);
       grphcs.drawString(mouse, 10, 20);
        circle.draw(circlex,circley,circlesize1,circlesize2);
        circle.draw(ccirclex,ccircley,ccirclesize1,ccirclesize2);
    }

    @Override
    public void update(GameContainer gc, StateBasedGame sbg, int i) throws SlickException {
        
        Input input=gc.getInput();
       int mousex=input.getMouseX();
       int mousey=input.getMouseY();
       mouse=" X: "+mousex+"    Y: "+mousey;
       
       
       
       
       
       if(input.isMouseButtonDown(0)){
           yolo=true;
           
       }
     
       
       //MUSIC
       if(!input.isMouseButtonDown(0) && mousex<435 && mousex>370 && mousey>189 && mousey<226 && yolo){
         circlex=370;circley=189;circlesize1=75;circlesize2=33; 
         yolo=false;
       }
       
        if(!input.isMouseButtonDown(0) && mousex<303 && mousex>247 && mousey>189 && mousey<224&& yolo){
         circlex=247;circley=190;circlesize1=56;circlesize2=33; 
         yolo=false;
       }
       
        //CONTROLS
        
        
        
       if(!input.isMouseButtonDown(0) && mousex<338 && mousex>216 && mousey>303 && mousey<336&& yolo){
         ccirclex=216;ccircley=303;ccirclesize1=122;ccirclesize2=36;
         yolo=false;
       } 
       
       if(!input.isMouseButtonDown(0) && mousex<501 && mousex>346 && mousey>300 && mousey<337&& yolo){
         ccirclex=346;ccircley=300;ccirclesize1=155;ccirclesize2=37;
         yolo=false;
       }
        
       if(input.isMouseButtonDown(0) && mousex<550 && mousex>464 && mousey>510 && mousey<537&& yolo){
           sbg.enterState(0, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
           yolo=false;
       }
       
       if(input.isMouseButtonDown(0) && mousex<214 && mousex>3 && mousey>505 && mousey<535&& yolo){
           sbg.enterState(3, new FadeOutTransition(Color.black,150), new FadeInTransition(Color.black,150));
           yolo=false;
       }
       
       
       
       
       
       
        
    }
}

//MUSIC
// off circle.draw(370,189,75,37);
//on int circlex=247,circley=190,circlesize1=56,circlesize2=33;


//CONTROLS
//mouse int ccirclex=216,ccircley=303,ccirclesize1=122,ccirclesize2=36;
//keys int ccirclex=346,ccircley=300,ccirclesize1=155,ccirclesize2=37;